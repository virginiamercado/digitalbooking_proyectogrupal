//export const BASE_URL="http://localhost:8080/"
export const BASE_URL="http://ec2-54-87-12-130.compute-1.amazonaws.com:8080/"
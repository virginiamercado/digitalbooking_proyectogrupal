window.addEventListener("load", () => {

    let form = document.querySelector(".formRegistro"),
        username = document.querySelector("#username"),
        rol = document.querySelector("#rol");
    form.addEventListener("submit", (e) => {
        e.preventDefault();

        let datos = {
            username : username.value,
            rol : {
                id : rol.value
            }
        }

        let config = {
            method : "PUT",
            headers: {
                'Content-Type': 'application/json'
            },
            body : JSON.stringify(datos)
        }

        fetch(`http://localhost:8080/usuarios/cambiar-rol`, config)
        .then((resp) => resp.json())
        .then((data) => console.log(data))
    })

})
import {caracteristicas} from '/modulosJs/caracteristicas.js';
import {card} from '/modulosJs/card.js';
import {cortarDescrip} from '/modulosJs/cortarDescrip.js';
import {estrellas} from '/modulosJs/estrellas.js';
import {verMas} from '/modulosJs/verMas.js';
import {BASE_URL} from '/modulosJs/constantes.js'

window.addEventListener("load", () => {

    let idUsuario = localStorage.getItem("idUsuario")

    fetch(BASE_URL + `reservas/usuario/${idUsuario}`)
    .then((resp) => resp.json())
    .then((data) => console.log(data))
    .catch((error) => console.log(error));


})